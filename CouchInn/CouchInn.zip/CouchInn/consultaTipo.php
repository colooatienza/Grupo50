<!DOCTYPE HTML>
<html>
<head>
  
  <meta charset="UTF-8">
  <title>CouchInn</title>

  
    
  <link rel="stylesheet" href="file:///C|/wamp/www/Css/c.css">
  <link rel="icon" href="file:///C|/wamp/www/Imagenes/icono.ico">

</head>
<body>
	<?php
	//include("file:///C|/wamp/www/verificarUsuario.php");
   include("conexion.php");
		
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from tipos_couch";
$result=$conn->query($sql);




?>


<table class="tablaSalas">
	<tr>
		<th>Nº</th>
		<th>Tipo</th>
		<th>Editar</th>
		<th>Borrar</th>
	</tr>
    <?php
		while($row=$result->fetch_array(MYSQLI_BOTH)){
			echo '<tr>';
			echo '<td>'.$row["id"].' </td> ';
			echo '<td>'.$row["tipo"]. '</td>';
			echo '<td><a href="modificarTipo.php?id='
		.$row["id"].'"><img src="images/editar.png" width="20" height="20"></a> </td>';
			echo '<td><img class="btnEliminar" width="20" height="20" onClick="confirmar('.$row["id"].')" src="images/eliminar.png"></td>';    
			echo '</tr>';   
		}
			?>
</table>
		
		
   
 
 
<footer class="footer">
  <p>Atienza Tomas - Ruiz Matias
</p>
</footer>

</body>
</html>
