<?php
	//$link = mysqli_connect("localhost", "root", "","couchinn");
	$conn = new mysqli("localhost", "root", "", "couchinn");
	//$link = new mysqli("localhost", "root", "", "couchinn");
    //mysqli_select_db("couchinn", $link);
?>
