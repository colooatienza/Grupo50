<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registrar Usuario</title>


<style type="text/css" media="screen">
  @import '../CouchInn/estilo/estilo.css';#apDiv2 {
	position: absolute;
	width: 100%;
	height: 70px;
	z-index: 0;
	top:0px;
	left:0px;
	background-color: #DDDDDD;
	border-width:2px;
}
#apDiv3 {
	position: absolute;
	width: 100%;
	height: 2px;
	z-index: 0;
	position:absolute;
	top:70px;
	left:0px;
	background-color: #888888;
	
}
.d {
	color: #CCC;
}
.d {
	color: #069;
}
</style>

<?php
	//include("file:///C|/wamp/www/verificarUsuario.php");
   include("conexion.php");
		
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$user_name = isset($_GET['us']) ? $_GET['us']:"";
$sql = "select * from usuarios where nombredeusuario='".$user_name."'";
$result=$conn->query($sql);

?>
 <div id="apDiv2"><span class="logo"><img src="images/logo.png"></span> <span class="decorado"><img src="images/casas.png" width=250px; height=55px;> </span></div>
<div id="apDiv3"></div>
</head>

<body onload="nobackbutton();">


   
     
   <div class="posicion_registo_usuario" id="apDiv1" >
    <span class="titulo"> <a href="consultaUsuarios.php"><img src="images/correcto.gif" width="20" height="20" alt="c" /></a>Usted se registró exitosamente:</span>     </p>
     <p><a href="consultaUsuarios.php" class="d"> | Volver a la página principal |</a>
       <?php   while($row=$result->fetch_array(MYSQLI_BOTH)){  ?> 
     </p>
     <table width="485" border="0" style="position: relative; left: -25px; border:none;" >
     <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
       <tr>
    <td width="230">Nombre de usuario:</td>
    <td width="239"><?php  echo utf8_encode($row["nombredeusuario"]); ?></td>
   
</tr>
  <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr> 
  <tr>
    <td>Clave de usuario:</td>
    <td><?php  echo utf8_encode($row["clave"]);?></td>
  </tr>
    <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr> 
   
  <tr>
    <td>Fecha de nacimiento:</td>
    <td><?php  echo utf8_encode($row["fechadenacimiento"]);?></td>
  </tr>
   <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr> 
    <tr>
    <td>Sexo:</td>
    <td><?php  echo utf8_encode($row["sexo"]); ?></td>
  </tr>
   <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr> 
  <tr>
    <td>Nacionalidad:</td>
    <td><?php  echo utf8_encode($row["nacionalidad"]); ?></td>
  </tr>
  <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  <tr>
    <td>e-Mail:</td>
    <td>.<?php  echo utf8_encode($row["mail"]); ?></td>
  </tr>
  <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  <tr>
    <td>Teléfono fijo:</td>
    <td>.<?php  echo utf8_encode($row["telefono"]); ?></td>
  </tr>
  <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  <tr>
    <td>Teléfono móvil:</td>
    <td>.<?php  echo utf8_encode($row["celular"]); ?></td>   
  </tr>
  <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  <tr>
    <td valign="bottom">Imagen de perfil:</td>
      <td>.
   <?php echo '<img src="imagen.php?id='.$row["idusuario"].' "style="max-width:150px; max-height:150px;    min-height:110px;" " onerror="this.src=\'images/sin_imagen.png\'">'; ?> </td>
</tr>
<tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  <tr>
    <td>Descripción personal:</td>
    <td>.<?php  echo utf8_encode($row["descripcion"]); ?></td>
  </tr>
 <tr> <td colspan="2"><hr class="linea_tabla"></td>  </tr>
  
 
</table>
     <p>
       <?php } ?>
     </p>
     <p><br>
       <br>
     </p>
     
</div>
 


<script language="javascript" src="registrarUsuario.js"></script> 
</body>
</html>