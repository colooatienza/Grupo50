<!DOCTYPE HTML>
<html>
<head>
  
  <meta charset="UTF-8">
  <title>CouchInn</title>

  
    
  <link rel="stylesheet" href="file:///C|/wamp/www/Css/c.css">
  <link rel="icon" href="file:///C|/wamp/www/Imagenes/icono.ico">

</head>
<body onload="nobackbutton();">
	<?php
	//include("file:///C|/wamp/www/verificarUsuario.php");
   include("conexion.php");
		
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select * from usuarios";
$result=$conn->query($sql);




?>


<table class="tablaSalas">
	<tr>
		<th>Nº</th>
		<th>Tipo</th>
		<th>Editar</th>
		<th>Borrar</th>
	</tr>
    <?php
		while($row=$result->fetch_array(MYSQLI_BOTH)){
			echo '<tr>';
			
			echo '<td>'.utf8_encode($row["idusuario"]).' </td> ';
			echo '<td>'.utf8_encode($row["nombredeusuario"]). '</td>';
	  	     echo '<td><img src="imagen.php?id='.$row["idusuario"].' "style="max-width:180px; max-height:180px;    min-height:110px;" " onerror="this.src=\'images/sin_imagen.png\'"></td>';
		 
			echo '<td><a href="modificarTipo.php?id='
		.$row["idusuario"].'"><img src="images/editar.png" width="20" height="20"></a> </td>';
			echo '<td><img class="btnEliminar" width="20" height="20" onClick="confirmar('.$row["idusuario"].')" src="images/eliminar.png"></td>';    
			echo '</tr>';   
		}
			?>
</table>
		
		
 
 
<footer class="footer">
  <p>Atienza Tomas - Ruiz Matias
</p>
</footer>

<script language="javascript" src="registrarUsuario.js"></script>
</body>
</html>
